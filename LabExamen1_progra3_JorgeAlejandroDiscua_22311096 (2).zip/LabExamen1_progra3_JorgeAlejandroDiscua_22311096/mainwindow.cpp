#include "mainwindow.h"
#include "./ui_mainwindow.h"


#include "gestordereservas.h"
#include "reserva.h"
#include "mesa.h"

#include <QDebug>
#include <QMessageBox>

GestorDeReservas gestor;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QList<Mesa> mesas = gestor.obtenerMesas();

    for (const Mesa& mesa : mesas) {
        ui->listaMesasDisp->addItem(mesa.getNombre()+" - "+mesa.getSalon());
    }
}


int codigo = 1;

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_4_clicked()
{
    exit(0);
}


void MainWindow::on_pushButton_12_clicked()
{
    if(!ui->leNombre->text().isEmpty() && !ui->leNumero->text().isEmpty()){

        int mesaIndex = ui->listaMesasDisp->currentRow();
        qDebug() << mesaIndex;

        QList<Mesa> mesas = gestor.obtenerMesas();
        Reserva reserva1(ui->leNombre->text(), ui->leNumero->text(), ui->sbComensales->value(), ui->calendarCrear->selectedDate(),ui->timeCrear->time(), codigo++, mesas[mesaIndex].getNombre());
        if(gestor.agregarReserva(reserva1, mesas[mesaIndex].getNombre())){
            ui->leNombre->setText("");
            ui->leNumero->setText("");
            ui->sbComensales->setValue(1);
            QMessageBox::information(this,"Reserva hecha", "Su codigo de reserva es: "+QString::number(reserva1.getCodigo()));
        }


    }else{
        QMessageBox::warning(this,"Error", "Llene todos los espacios vacios");
    }




}


void MainWindow::on_pushButton_15_clicked()
{
    if(!ui->leCodigoEliminar->text().isEmpty() && !ui->leNombreEliminar->text().isEmpty()){
        if(gestor.verificarReserva(ui->leNombreEliminar->text(), ui->leCodigoEliminar->text().toInt())){
            if(gestor.eliminarReserva(ui->leCodigoEliminar->text().toInt())){
                QMessageBox::information(this,"Se ha eliminado", "Se ha eliminado la reserva exitosamente");
                ui->leCodigoEliminar->setText("");
                ui->leNombreEliminar->setText("");
            }else{
                QMessageBox::information(this,"No se encontro", "No se ha encontrado la reserva a eliminar");
            }
        }else{
            QMessageBox::warning(this,"Error", "Alguno de los datos ingresados no coincide");
        }
    }else{
        QMessageBox::warning(this, "Error", "Por favor llene todos los espacios solicitados");
    }
}


void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_13_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MainWindow::on_pushButton_16_clicked()
{
    if(!ui->leCodigoModificar->text().isEmpty() && !ui->leNombreModificar->text().isEmpty()){
        if(gestor.verificarReserva(ui->leNombreModificar->text(), ui->leCodigoModificar->text().toInt())){
            ui->stackedWidget_3->setCurrentIndex(1);
        }else{
            QMessageBox::warning(this,"Error", "Alguno de los datos ingresados no coincide");
        }
    }else{
        QMessageBox::warning(this, "Error", "Por favor llene todos los espacios solicitados");
    }
}


void MainWindow::on_pushButton_17_clicked()
{
    if(!ui->leNombreMod->text().isEmpty() && !ui->leContactoMod->text().isEmpty()){
        gestor.modificarReserva(ui->leCodigoModificar->text().toInt(),ui->leNombreMod->text(),ui->leContactoMod->text(),ui->sbComensalesMod->value(),ui->calendarMod->selectedDate(),ui->timeMod->time());
        QMessageBox::information(this,"Datos modificados", "Se ha modificado la reserva");
        ui->leNombreMod->setText("");
        ui->leContactoMod->setText("");
        ui->sbComensalesMod->setValue(1);
    }else{
        QMessageBox::warning(this,"Error", "Llene todos los espacios vacios");
    }
}


void MainWindow::on_pushButton_14_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->stackedWidget_3->setCurrentIndex(0);
}


void MainWindow::on_pushButton_8_clicked()
{
    ui->listaMesasDisp->clear();
    QList<Mesa> mesas = gestor.obtenerMesas();

    for (const Mesa& mesa : mesas) {
        ui->listaMesasDisp->addItem(mesa.getNombre()+" - "+mesa.getSalon());
    }
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MainWindow::on_pushButton_5_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}


void MainWindow::on_pushButton_6_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(0);
}


void MainWindow::on_pushButton_18_clicked()
{
    Mesa nuevaMesa(ui->leMesaCrear->text(), ui->leSalonMesaCrear->text());
    gestor.agregarMesa(nuevaMesa);
    QMessageBox::information(this,"Se ha creado", "Se ha creado una nueva mesa");
}


void MainWindow::on_pushButton_19_clicked()
{
    gestor.eliminarMesa(ui->leDeshabMesa->text());
    QMessageBox::information(this,"Se ha eliminado", "Se ha eliminado la mesa");
    ui->leDeshabMesa->setText("");
}


void MainWindow::on_pushButton_9_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}


void MainWindow::on_pushButton_10_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}


void MainWindow::on_pushButton_11_clicked()
{
    ui->listaVerReservas->clear();


    for (const Reserva& reserva : gestor.obtenerReservas()) {
        QString itemText = reserva.getMesa() + " - Reservación a nombre de " + reserva.getNombreDelRepresentante();
        ui->listaVerReservas->addItem(itemText);
    }
    ui->stackedWidget->setCurrentIndex(6);
}


void MainWindow::on_listaVerReservas_itemClicked(QListWidgetItem *item)
{
    int row = ui->listaVerReservas->currentRow();

    if(row>=0 && row < gestor.getContadorReservas()){
        QList<Reserva> reservas = gestor.obtenerReservas();
        Reserva reservaSeleccionada = reservas.at(row);
        /*
        QString mostrar;
        mostrar.append("Titulo: "+tareaSeleccionada->getTitulo()+"\n");
        mostrar.append("Fecha: "+)
        */
        QString mostrar;
        mostrar.append(reservaSeleccionada.getMesa());
        mostrar.append("\nNombre del representante: "+reservaSeleccionada.getNombreDelRepresentante());
        mostrar.append("\nNumero del contacto: "+reservaSeleccionada.getNumeroDeContacto());
        mostrar.append("\nNumero de comensales: "+QString::number(reservaSeleccionada.getComensales()));
        mostrar.append("\nFecha y hora:"+reservaSeleccionada.getFecha().toString()+" "+reservaSeleccionada.getHora().toString());
        ui->descReserva->setText(mostrar);
    }
}



void MainWindow::on_listaMesasRevisar_itemClicked(QListWidgetItem *item)
{
    QString nombreItem = item->text();

    QString nombreMesa = nombreItem.split(" - ").first();
    ui->textEditHorasOcupadas->clear(); // Limpia el QTextEdit antes de agregar nuevo contenido

    for (const Mesa& mesa : gestor.obtenerMesas()) {
        if (mesa.getNombre() == nombreMesa) {
            // Agregar un encabezado en el QTextEdit
            ui->textEditHorasOcupadas->insertPlainText("Reservaciones en esta mesa:\n");

            // Iterar sobre las reservas asociadas a esta mesa
            for (const Reserva& reserva : mesa.getReservas()) {
                // Formato para mostrar la fecha y la hora de la reserva
                QString infoReserva = QString("- Mesa reservada el %1 a las %2\n")
                                          .arg(reserva.getFecha().toString("dd/MM/yyyy"))
                                          .arg(reserva.getHora().toString("HH:mm"));
                // Agregar la información al QTextEdit con un salto de línea al final
                ui->textEditHorasOcupadas->insertPlainText(infoReserva);
            }
            break; // Salir del loop una vez encontrada la mesa
        }
    }
}


void MainWindow::on_pushButton_7_clicked()
{
    qDebug()<< "click";
    ui->stackedWidget->setCurrentIndex(3);
    ui->listaMesasRevisar->clear();

    QList<Mesa> mesas = gestor.obtenerMesas();

    for (const Mesa& mesa : mesas) {
        ui->listaMesasRevisar->addItem(mesa.getNombre()+" - "+mesa.getSalon());
    }
}


void MainWindow::on_pushButton_20_clicked()
{
    qDebug()<< "click";
    ui->stackedWidget->setCurrentIndex(3);
    ui->listaMesasRevisar->clear();

    QList<Mesa> mesas = gestor.obtenerMesas();

    for (const Mesa& mesa : mesas) {
        ui->listaMesasRevisar->addItem(mesa.getNombre()+" - "+mesa.getSalon());
    }
}

