#ifndef GESTORDERESERVAS_H
#define GESTORDERESERVAS_H

#include <QList>
#include <QMessageBox>

#include "Reserva.h"
#include "mesa.h"

class GestorDeReservas {
public:
    GestorDeReservas();

    bool agregarReserva(const Reserva& reserva, const QString& nombreMesa);

    void agregarMesa(const Mesa& mesa);

    QList<Reserva> obtenerReservas() const;

    QList<Mesa> obtenerMesas() const;

    Reserva* buscarReservaPorNombre(const QString& nombre);

    bool eliminarReserva(const int codigo);

    bool eliminarMesa(const QString& nombre);

    int getContadorReservas() const;

    bool verificarReserva(const QString& nombre, int codigo) const;

    void modificarReserva(int codigo, const QString& nombreDelRepresentante, const QString& numeroDeContacto, int comensales, const QDate& fecha, const QTime& hora);

    void modificarMesa(const QString& nombre, const QString& nuevoNombre, const QString& nuevoSalon);
private:
    QList<Reserva> reservas;
    QList<Mesa> mesas;
    int contadorReservas;
};

#endif // GESTORDERESERVAS_H
