#include "mesa.h"

// Constructor
Mesa::Mesa(const QString& nombre, const QString& salon)
    : nombre(nombre), salon(salon) {}

// Obtener el nombre de la mesa
QString Mesa::getNombre() const {
    return nombre;
}

// Obtener el salón de la mesa
QString Mesa::getSalon() const {
    return salon;
}

// Obtener todas las reservas de la mesa
QList<Reserva> Mesa::getReservas() const {
    return reservas;
}

// Agregar una reserva a la mesa
void Mesa::agregarReserva(const Reserva& reserva) {
    reservas.append(reserva);
}

// Eliminar una reserva de la mesa por código
bool Mesa::eliminarReserva(int codigo) {
    for (int i = 0; i < reservas.size(); ++i) {
        if (reservas[i].getCodigo() == codigo) {
            reservas.removeAt(i);
            return true; // Reserva eliminada con éxito
        }
    }
    return false; // Código no encontrado
}

// Verificar si una reserva existe en la mesa por código
bool Mesa::verificarReserva(int codigo) const {
    for (const Reserva& reserva : reservas) {
        if (reserva.getCodigo() == codigo) {
            return true; // Reserva encontrada
        }
    }
    return false; // Reserva no encontrada
}
