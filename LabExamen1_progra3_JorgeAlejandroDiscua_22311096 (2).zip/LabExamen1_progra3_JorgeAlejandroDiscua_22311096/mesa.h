#ifndef MESA_H
#define MESA_H

#include <QString>
#include <QList>

#include "reserva.h"

class Mesa
{
public:
    Mesa(const QString& nombre, const QString& salon);

    QString getNombre() const;
    QString getSalon() const;
    QList<Reserva> getReservas() const;
    void agregarReserva(const Reserva& reserva);
    bool eliminarReserva(int codigo);
    bool verificarReserva(int codigo) const;

private:
    QString nombre;
    QString salon;
    QList<Reserva> reservas;
};

#endif // MESA_H
