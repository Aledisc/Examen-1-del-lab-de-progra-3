#include "reserva.h"

//constructor
Reserva::Reserva(const QString& nombre, const QString& contacto, int comensales, const QDate& fecha, const QTime& hora, int codigo, QString mesa)
    : nombreDelRepresentante(nombre), numeroDeContacto(contacto), comensales(comensales), fecha(fecha), hora(hora), codigo(codigo), mesa(mesa){}

//getters
QString Reserva::getNombreDelRepresentante() const {
    return nombreDelRepresentante;
}

QString Reserva::getNumeroDeContacto() const {
    return numeroDeContacto;
}

int Reserva::getComensales() const {
    return comensales;
}

QDate Reserva::getFecha() const {
    return fecha;
}

QTime Reserva::getHora() const {
    return hora;
}

int Reserva::getCodigo() const {
    return codigo;
}

QString Reserva::getMesa() const {
    return mesa;
}

//setters
void Reserva::setNombreDelRepresentante(const QString& nombre) {
    nombreDelRepresentante = nombre;
}

void Reserva::setNumeroDeContacto(const QString& contacto) {
    numeroDeContacto = contacto;
}

void Reserva::setComensales(int comensales) {
    this->comensales = comensales;
}

void Reserva::setFecha(const QDate& fecha) {
    this->fecha = fecha;
}

void Reserva::setHora(const QTime& hora) {
    this->hora = hora;
}

void Reserva::setMesa(const QString& mesa){
    this->mesa = mesa;
}
